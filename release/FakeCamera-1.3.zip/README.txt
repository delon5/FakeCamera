FakeCamera 1.3

1. Copy the content of the "ux0" folder to the root of ux0: on the memory card
   (it holds tai/fakecamera.suprx and data/FakeCamera/...).
2. Add to ux0:tai/config.txt (or ur0:tai/config.txt if that is the one you use):

   *ALL
   ux0:tai/fakecamera.suprx

   and remove any old fakecamerabmp.suprx / fakecamerakbmp.suprx line.
3. Optional, for titles which cannot read ux0: (Frobisher Says): copy ioplus.skprx
   to ur0:tai/ and add it under *KERNEL.
4. Reboot.
